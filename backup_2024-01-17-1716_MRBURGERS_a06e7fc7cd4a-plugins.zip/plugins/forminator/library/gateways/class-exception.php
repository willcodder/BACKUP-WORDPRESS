<?php

/**
 * Gateway Exception catcher
 * Class Forminator_Gateway_Exception
 *
 * @since 1.7
 */
class Forminator_Gateway_Exception extends Exception {
}
