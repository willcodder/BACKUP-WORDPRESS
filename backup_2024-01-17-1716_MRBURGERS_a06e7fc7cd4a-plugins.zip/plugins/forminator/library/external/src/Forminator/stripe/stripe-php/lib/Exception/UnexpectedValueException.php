<?php

namespace Forminator\Stripe\Exception;

class UnexpectedValueException extends \UnexpectedValueException implements ExceptionInterface
{
}
