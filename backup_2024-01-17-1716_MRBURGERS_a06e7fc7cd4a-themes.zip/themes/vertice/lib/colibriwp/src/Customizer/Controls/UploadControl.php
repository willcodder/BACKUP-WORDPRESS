<?php


namespace ColibriWP\Theme\Customizer\Controls;

use WP_Customize_Upload_Control;

class UploadControl extends WP_Customize_Upload_Control {
	use ColibriWPControlsAdapter;
}
