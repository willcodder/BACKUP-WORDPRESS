<?php $component = \ColibriWP\Theme\View::getData( 'component' ); ?>
<div class="wp-block wp-block-kubio-buttongroup  position-relative wp-block-kubio-buttongroup__outer vertice-front-header__k__9uoTT9gnxCy-outer vertice-local-137-outer h-x-container" data-kubio="kubio/buttongroup">
	<div class="position-relative wp-block-kubio-buttongroup__spacing vertice-front-header__k__9uoTT9gnxCy-spacing vertice-local-137-spacing h-x-container-inner">
		<?php $component->printButtons(); ?>
	</div>
</div>
