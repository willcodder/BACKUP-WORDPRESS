<?php $component = \ColibriWP\Theme\View::getData( 'component' ); ?>
<ul class="wp-block wp-block-kubio-iconlist  position-relative wp-block-kubio-iconlist__outer vertice-front-header__k__g-k9UFoytmN-outer vertice-local-94-outer ul-list-icon list-type-horizontal-on-desktop list-type-horizontal-on-tablet list-type-horizontal-on-mobile" data-kubio="kubio/iconlist">
	<?php $component->printIcons(); ?>
</ul>
