<a href="<?php echo esc_url(\ColibriWP\Theme\View::getData('link_value')); ?>" class="wp-block wp-block-kubio-social-icon  position-relative wp-block-kubio-social-icon__link vertice-front-header__k__E5QU9RkrEjd-link vertice-local-106-link social-icon-link" data-kubio="kubio/social-icon">
	<span class="h-svg-icon wp-block-kubio-social-icon__icon vertice-front-header__k__E5QU9RkrEjd-icon vertice-local-106-icon" name="font-awesome/vimeo-square">
		<?php $icon = \ColibriWP\Theme\View::getData('icon'); if (isset($icon['content'])) echo $icon['content'] ?>
	</span>
</a>
