<?php $component = \ColibriWP\Theme\View::getData( 'component' ); ?>
<h1 class="wp-block wp-block-kubio-heading  position-relative wp-block-kubio-heading__text vertice-front-header__k__ukjZtaF3MN-text vertice-local-130-text" data-kubio="kubio/heading">
	<?php $component->printTitle(); ?>
</h1>
