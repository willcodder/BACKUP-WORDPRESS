<div class="wp-block wp-block-kubio-query-loop  position-relative wp-block-kubio-query-loop__container vertice-search__k__vrf0UGkWrN-container vertice-local-547-container gutters-row-lg-3 gutters-row-v-lg-3 gutters-row-md-3 gutters-row-v-md-3 gutters-row-0 gutters-row-v-3" data-kubio="kubio/query-loop" data-kubio-component="masonry" data-kubio-settings="{&quot;enabled&quot;:true,&quot;targetSelector&quot;:&quot;.wp-block-kubio-query-loop__inner&quot;}">
	<div class="position-relative wp-block-kubio-query-loop__inner vertice-search__k__vrf0UGkWrN-inner vertice-local-547-inner h-row">
		<?php vertice_theme()->get('archive-loop')->render(array (
  'view' => 'content/search/loop-item',
)); ?>
	</div>
</div>
