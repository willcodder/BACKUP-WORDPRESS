<div id="post-<?php the_ID(); ?>" class=" <?php get_post_class() ?> wp-block wp-block-kubio-query-layout  position-relative wp-block-kubio-query-layout__outer vertice-single__k__single-lAFSH8Xo9x-outer vertice-local-670-outer d-flex h-section-global-spacing align-items-lg-center align-items-md-center align-items-center" data-kubio="kubio/query-layout" id="blog-layout">
	<div class="position-relative wp-block-kubio-query-layout__inner vertice-single__k__single-lAFSH8Xo9x-inner vertice-local-670-inner h-section-grid-container h-section-boxed-container">
		<div class="wp-block wp-block-kubio-row  position-relative wp-block-kubio-row__container vertice-single__k__single-baLWB4dRKjp-container vertice-local-671-container gutters-row-lg-0 gutters-row-v-lg-0 gutters-row-md-0 gutters-row-v-md-0 gutters-row-0 gutters-row-v-0" data-kubio="kubio/row">
			<div class="position-relative wp-block-kubio-row__inner vertice-single__k__single-baLWB4dRKjp-inner vertice-local-671-inner h-row align-items-lg-stretch align-items-md-stretch align-items-stretch justify-content-lg-center justify-content-md-center justify-content-center gutters-col-lg-0 gutters-col-v-lg-0 gutters-col-md-0 gutters-col-v-md-0 gutters-col-0 gutters-col-v-0">
				<div class="wp-block wp-block-kubio-column  position-relative wp-block-kubio-column__container vertice-single__k__single-kxeqsSpdy-n-container vertice-local-672-container d-flex h-col-lg-auto h-col-md-auto h-col-auto" data-kubio="kubio/column">
					<div class="position-relative wp-block-kubio-column__inner vertice-single__k__single-kxeqsSpdy-n-inner vertice-local-672-inner d-flex h-flex-basis h-px-lg-2 v-inner-lg-2 h-px-md-2 v-inner-md-2 h-px-2 v-inner-2">
						<div class="position-relative wp-block-kubio-column__align vertice-single__k__single-kxeqsSpdy-n-align vertice-local-672-align h-y-container h-column__content h-column__v-align flex-basis-100 align-self-lg-start align-self-md-start align-self-start">
							<div class="wp-block wp-block-kubio-divider  position-relative wp-block-kubio-divider__outer vertice-single__k__5Y-cAwiw7-outer vertice-local-673-outer" data-kubio="kubio/divider" id="divider">
								<div class="position-relative wp-block-kubio-divider__width-container vertice-single__k__5Y-cAwiw7-width-container vertice-local-673-width-container">
									<div class="position-relative wp-block-kubio-divider__line vertice-single__k__5Y-cAwiw7-line vertice-local-673-line"></div>
								</div>
							</div>
							<div class="wp-block wp-block-kubio-post-meta  position-relative wp-block-kubio-post-meta__metaDataContainer vertice-single__k__KGesgqe_P-metaDataContainer vertice-local-674-metaDataContainer h-blog-meta" data-kubio="kubio/post-meta" id="post-metadata">
								<span class="metadata-item">
									<a href="<?php echo esc_url(get_day_link(get_post_time( 'Y' ),get_post_time( 'm' ),get_post_time( 'j' ))); ?>">
										<?php echo esc_html(get_the_date('F j, Y')); ?>
									</a>
								</span>
								<span class="metadata-separator">
									|
								</span>
								<span class="metadata-item">
									<a href="">
										<?php echo esc_html(get_the_time()); ?>
									</a>
								</span>
							</div>
							<figure class="wp-block wp-block-kubio-post-featured-image  position-relative wp-block-kubio-post-featured-image__container vertice-single__k__single-rlYTEhTMib-container vertice-local-675-container kubio-post-featured-image--has-image h-aspect-ratio--16-9 <?php vertice_post_missing_featured_image_class(); ?>" data-kubio="kubio/post-featured-image" data-kubio-settings="{{kubio_settings_value}}">
								<?php if(has_post_thumbnail()): ?>
								<img class='position-relative wp-block-kubio-post-featured-image__image vertice-single__k__single-rlYTEhTMib-image vertice-local--image' src='<?php echo esc_url(get_the_post_thumbnail_url());?>' />
								<?php endif; ?>
								<div class="position-relative wp-block-kubio-post-featured-image__inner vertice-single__k__single-rlYTEhTMib-inner vertice-local-675-inner">
									<div class="position-relative wp-block-kubio-post-featured-image__align vertice-single__k__single-rlYTEhTMib-align vertice-local-675-align h-y-container align-self-lg-end align-self-md-end align-self-end"></div>
								</div>
							</figure>
							<div class="wp-block wp-block-kubio-row  position-relative wp-block-kubio-row__container vertice-single__k__single-SbdKxHs2YI-container vertice-local-676-container gutters-row-lg-0 gutters-row-v-lg-0 gutters-row-md-0 gutters-row-v-md-0 gutters-row-0 gutters-row-v-0" data-kubio="kubio/row">
								<div class="position-relative wp-block-kubio-row__inner vertice-single__k__single-SbdKxHs2YI-inner vertice-local-676-inner h-row align-items-lg-stretch align-items-md-stretch align-items-stretch justify-content-lg-center justify-content-md-center justify-content-center gutters-col-lg-0 gutters-col-v-lg-0 gutters-col-md-0 gutters-col-v-md-0 gutters-col-0 gutters-col-v-0">
									<div class="wp-block wp-block-kubio-column  position-relative wp-block-kubio-column__container vertice-single__k__single-3VGwAjm9cX-container vertice-local-677-container d-flex h-col-lg-auto h-col-md-auto h-col-auto" data-kubio="kubio/column">
										<div class="position-relative wp-block-kubio-column__inner vertice-single__k__single-3VGwAjm9cX-inner vertice-local-677-inner d-flex h-flex-basis h-px-lg-0 v-inner-lg-0 h-px-md-0 v-inner-md-0 h-px-0 v-inner-0">
											<div class="position-relative wp-block-kubio-column__align vertice-single__k__single-3VGwAjm9cX-align vertice-local-677-align h-y-container h-column__content h-column__v-align flex-basis-100 align-self-lg-start align-self-md-start align-self-start">
												<?php the_content(); ?>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="wp-block wp-block-kubio-row  position-relative wp-block-kubio-row__container vertice-single__k__single-1uGRU27HVz-container vertice-local-678-container gutters-row-lg-0 gutters-row-v-lg-1 gutters-row-md-0 gutters-row-v-md-1 gutters-row-0 gutters-row-v-1" data-kubio="kubio/row">
								<div class="position-relative wp-block-kubio-row__inner vertice-single__k__single-1uGRU27HVz-inner vertice-local-678-inner h-row align-items-lg-stretch align-items-md-stretch align-items-stretch justify-content-lg-start justify-content-md-start justify-content-start gutters-col-lg-0 gutters-col-v-lg-1 gutters-col-md-0 gutters-col-v-md-1 gutters-col-0 gutters-col-v-1">
									<div class="wp-block wp-block-kubio-column  position-relative wp-block-kubio-column__container vertice-single__k__single-K4Akm2YNqS-container vertice-local-679-container d-flex h-col-lg-auto h-col-md-auto h-col-auto" data-kubio="kubio/column">
										<div class="position-relative wp-block-kubio-column__inner vertice-single__k__single-K4Akm2YNqS-inner vertice-local-679-inner d-flex h-flex-basis h-px-lg-0 v-inner-lg-1 h-px-md-0 v-inner-md-1 h-px-0 v-inner-1">
											<div class="position-relative wp-block-kubio-column__align vertice-single__k__single-K4Akm2YNqS-align vertice-local-679-align h-y-container h-column__content h-column__v-align flex-basis-auto align-self-lg-start align-self-md-start align-self-start">
												<p class="wp-block wp-block-kubio-text  position-relative wp-block-kubio-text__text vertice-single__k__single-1pwRcGAnh-text vertice-local-680-text" data-kubio="kubio/text">
													<?php esc_html_e('Tags:', 'vertice'); ?>
												</p>
											</div>
										</div>
									</div>
									<div class="wp-block wp-block-kubio-column  position-relative wp-block-kubio-column__container vertice-single__k__single-LfW21x_joR-container vertice-local-681-container d-flex h-col-lg h-col-md h-col" data-kubio="kubio/column">
										<div class="position-relative wp-block-kubio-column__inner vertice-single__k__single-LfW21x_joR-inner vertice-local-681-inner d-flex h-flex-basis h-px-lg-1 v-inner-lg-1 h-px-md-1 v-inner-md-1 h-px-1 v-inner-1">
											<div class="position-relative wp-block-kubio-column__align vertice-single__k__single-LfW21x_joR-align vertice-local-681-align h-y-container h-column__content h-column__v-align flex-basis-100 align-self-lg-start align-self-md-start align-self-start">
												<div class="wp-block wp-block-kubio-post-tags  position-relative wp-block-kubio-post-tags__container vertice-single__k__single-tlSt_AyBi-container vertice-local-682-container kubio-post-tags-container" data-kubio="kubio/post-tags">
													<div class="position-relative wp-block-kubio-post-tags__placeholder vertice-single__k__single-tlSt_AyBi-placeholder vertice-local-682-placeholder kubio-post-tags-placeholder"></div>
													<div class="position-relative wp-block-kubio-post-tags__tags vertice-single__k__single-tlSt_AyBi-tags vertice-local-682-tags">
														<?php vertice_tags_list(__('No tags', 'vertice')); ?>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							<?php if(vertice_has_pagination()): ?>
							<div class="wp-block wp-block-kubio-query-pagination  position-relative wp-block-kubio-query-pagination__container vertice-single__k__single-nqLiVZCaYo-container vertice-local-683-container gutters-row-lg-0 gutters-row-v-lg-2 gutters-row-md-0 gutters-row-v-md-2 gutters-row-0 gutters-row-v-2" data-kubio="kubio/query-pagination">
								<div class="position-relative wp-block-kubio-query-pagination__inner vertice-single__k__single-nqLiVZCaYo-inner vertice-local-683-inner h-row align-items-lg-stretch align-items-md-stretch align-items-stretch justify-content-lg-center justify-content-md-center justify-content-center gutters-col-lg-0 gutters-col-v-lg-2 gutters-col-md-0 gutters-col-v-md-2 gutters-col-0 gutters-col-v-2">
									<div class="wp-block wp-block-kubio-column  position-relative wp-block-kubio-column__container vertice-single__k__single-3ndM77FkZV-container vertice-local-684-container d-flex h-col-lg h-col-md h-col-auto" data-kubio="kubio/column">
										<div class="position-relative wp-block-kubio-column__inner vertice-single__k__single-3ndM77FkZV-inner vertice-local-684-inner d-flex h-flex-basis h-px-lg-0 v-inner-lg-2 h-px-md-0 v-inner-md-2 h-px-0 v-inner-2">
											<div class="position-relative wp-block-kubio-column__align vertice-single__k__single-3ndM77FkZV-align vertice-local-684-align h-y-container h-column__content h-column__v-align flex-basis-100 align-self-lg-start align-self-md-start align-self-start">
												<?php if(vertice_has_pagination_button(true)): ?>
												<div class="position-relative wp-block-kubio-pagination-nav-button__spacing vertice-single__k__single-ELgmeRXRD--spacing vertice-local-685-spacing">
													<span class="wp-block wp-block-kubio-pagination-nav-button  position-relative wp-block-kubio-pagination-nav-button__outer vertice-single__k__single-ELgmeRXRD--outer vertice-local-685-outer kubio-button-container" data-kubio="kubio/pagination-nav-button">
														<a class="position-relative wp-block-kubio-pagination-nav-button__link vertice-single__k__single-ELgmeRXRD--link vertice-local-685-link h-w-100 h-global-transition" href="<?php vertice_get_navigation_button_link(true); ?>">
															<span class="position-relative wp-block-kubio-pagination-nav-button__text vertice-single__k__single-ELgmeRXRD--text vertice-local-685-text kubio-inherit-typography">
																<?php esc_html_e('Previous', 'vertice'); ?>
															</span>
														</a>
													</span>
												</div>
												<?php endif; ?>
											</div>
										</div>
									</div>
									<div class="wp-block wp-block-kubio-column  position-relative wp-block-kubio-column__container vertice-single__k__single-mMPMCQqWfs-container vertice-local-686-container d-flex h-col-lg h-col-md h-col-auto" data-kubio="kubio/column">
										<div class="position-relative wp-block-kubio-column__inner vertice-single__k__single-mMPMCQqWfs-inner vertice-local-686-inner d-flex h-flex-basis h-px-lg-0 v-inner-lg-2 h-px-md-0 v-inner-md-2 h-px-0 v-inner-2">
											<div class="position-relative wp-block-kubio-column__align vertice-single__k__single-mMPMCQqWfs-align vertice-local-686-align h-y-container h-column__content h-column__v-align flex-basis-100 align-self-lg-start align-self-md-start align-self-start">
												<?php if(vertice_has_pagination_button()): ?>
												<div class="position-relative wp-block-kubio-pagination-nav-button__spacing vertice-single__k__single-ACSe8L2gsX-spacing vertice-local-687-spacing">
													<span class="wp-block wp-block-kubio-pagination-nav-button  position-relative wp-block-kubio-pagination-nav-button__outer vertice-single__k__single-ACSe8L2gsX-outer vertice-local-687-outer kubio-button-container" data-kubio="kubio/pagination-nav-button">
														<a class="position-relative wp-block-kubio-pagination-nav-button__link vertice-single__k__single-ACSe8L2gsX-link vertice-local-687-link h-w-100 h-global-transition" href="<?php vertice_get_navigation_button_link(); ?>">
															<span class="position-relative wp-block-kubio-pagination-nav-button__text vertice-single__k__single-ACSe8L2gsX-text vertice-local-687-text kubio-inherit-typography">
																<?php esc_html_e('Next', 'vertice'); ?>
															</span>
														</a>
													</span>
												</div>
												<?php endif; ?>
											</div>
										</div>
									</div>
								</div>
							</div>
							<?php endif; ?>
							<div class="wp-block wp-block-kubio-post-comments kubio-migration--1 position-relative wp-block-kubio-post-comments__commentsContainer vertice-single__k__single-s5UQRGEAN-commentsContainer vertice-local-688-commentsContainer" data-kubio="kubio/post-comments">
								<?php vertice_post_comments(array (
  'none' => __('No responses yet', 'vertice'),
  'one' => __('One response', 'vertice'),
  'multiple' => __('{COMMENTS-COUNT} Responses', 'vertice'),
  'disabled' => __('Comments are closed', 'vertice'),
  'avatar_size' => __('32', 'vertice'),
)); ?>
							</div>
							<div class="wp-block wp-block-kubio-post-comments-form  position-relative wp-block-kubio-post-comments-form__container vertice-single__k__single-oXoikmHxB-container vertice-local-689-container" data-kubio="kubio/post-comments-form">
								<?php comment_form(); ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
